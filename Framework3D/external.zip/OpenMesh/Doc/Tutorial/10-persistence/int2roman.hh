#ifndef INT2ROMAN_HH
#define INT2ROMAN_HH

#include <string>

std::string int2roman( size_t decimal, size_t length=30 );

#endif
