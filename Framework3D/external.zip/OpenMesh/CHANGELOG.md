The changelog can be found in the html Documentation.

The latest changelog for the master can be found here:
http://openmesh.org/Daily-Builds/Doc/
